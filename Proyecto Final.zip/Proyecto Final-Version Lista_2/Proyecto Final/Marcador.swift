//
//  Marcador.swift
//  Proyecto Final
//
//  Created by Macbook on 12/5/18.
//  Copyright © 2018 ioslab. All rights reserved.
//

import UIKit
import MapKit

class Marcador: MKPointAnnotation {
    
    var imagenURL: String!
    
}
